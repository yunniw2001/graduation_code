# PalmPrint
A Palmprint ROI segmentation method


一种最常用经典的掌纹ROI提取方法(最大内切圆法)


采用matlab编程。具体算法可参考论文[1]

[1]李文新,夏胜雄,张大鹏,许卓群.基于主线特征的双向匹配的掌纹识别新方法[J].计算机研究与发展,2004(06):996-1002.




One of the most commonly used classic palmprint ROI extraction methods (maximum inscribed circle method)


Programming with matlab. Specific algorithms can refer to the literature [1]



[1]Wen L I , Sheng X , Da Z , et al. A New Palmprint Identification Method Using Bi-Directional Matching Based on Major Line Features[J]. Journal of Computer Research and Development, 2004, 41(6):996-1002.
